'''
Converts from and to base64
'''
import base64

import typer
from cli import Logger

__version__ = '1.0.0'
app = typer.Typer()
logger = Logger('base64')


@app.command()
def code(string: str):
    logger.info('Encoding string %s to base64', string)
    print(base64.b64encode(string.encode('utf8')).decode('utf8'))


@app.command()
def decode(string: str):
    logger.info('Decoding base64 string %s to plain text', string)
    print(base64.b64decode(string.encode('utf8')).decode('utf8'))
