'''
Converts dates to different formats
'''
import datetime

from rich import print
import typer


__version__ = '1.0.0'
app = typer.Typer()


@app.command()
def date(timestamp: int, ms: bool = typer.Option(True, '--ms')) -> int:
    '''Converts a timestamp into an ISO8601 date'''
    if ms:
        timestamp //= 1000
    print(datetime.datetime.fromtimestamp(timestamp).isoformat())
    return 0


@app.command()
def iso(
    date: str,
    format: str = typer.Option('%Y-%m-%dT%H:%M:%S', '--format', '-f')
) -> int:
    '''Converts a date from a format into an ISO8601 date'''
    print(datetime.datetime.strptime(date, format).isoformat())
    return 0


@app.command()
def tz(date: datetime.datetime, timezone: str = typer.Option(None, '--tz')) -> int:
    '''Converts an ISO8601 date into a different time zone'''
    date: datetime.datetime = datetime.datetime.fromisoformat(date)
    date.replace(tzinfo=datetime.timezone.utc).astimezone(tz=timezone)
    print(date.isoformat())
    return 0
